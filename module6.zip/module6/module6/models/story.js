const { DateTime } = require("luxon");
const stories = [
    {
        id: '1',
        title: 'My life at Charlotte',
        content: 'Charlotte is very cool. There are lots of places to eat at like Halal Cart. It is very yummy. Yum.',
        author: 'Alex Moore',
        createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)

    },
    {
        id: '2',
        title: 'Learning NBAD',
        content: 'Learning NBAD is cool. Swag, if I may. Learning NBAD will make me more swaggy.',
        author: 'Alex Moore',
        createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    },
    {
        id: '3',
        title: 'My Spring Break',
        content: 'This Spring Break I will be going to the beach. I will be going to the beach with my friends. We will have a lot of fun. We will play with a beach ball if we are feeling crazy',
        author: 'Alex Moore',
        createdAt: DateTime.now().toLocaleString(DateTime.DATETIME_SHORT)
    }
];

exports.find = () => stories;

exports.findByID = id => stories.find(story=>story.id === id); 
