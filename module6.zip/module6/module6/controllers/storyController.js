const model = require('../models/story');

exports.index = (req, res) => {
    //res.send('send all stories');
    let stories = model.find();
    res.render('./story/index', {stories});
};

// GET /stories/new: send the HTML form for creating a new story
exports.new = (req, res) => {
    res.send('send the new form');
};

// POST /stories: create a new story
exports.create = (req, res) => {
    res.send('create a new story');
};

// GET /stories/:id: send the details of story identify by id with id = :id
exports.show = (req, res) => {
    let id = req.params.id;
    let story = model.findByID(id);
    if (story) {
        res.render('./story/show', {story});
    }
    res.status(404).send('Cannot find story with id ' + id);
    res.render('./story/show', {story});
};

// GET /stories/:id/edit: send the HTML form for editing a story
exports.edit = (req, res) => {
    res.send('send the edit form' + req.params.id);
};

// PUT /stories/:id: update the story identify by id
exports.update = (req, res) => {
    res.send('update the story with id ' + req.params.id);
};

// DELETE /stories/:id: delete the story identify by id
exports.delete = (req, res) => {
    res.send('delete the story with id ' + req.params.id);
};